/**
 * Created by Ade on 5/9/2017.
 */
public interface CheckersGameInterface {
public void movePlayer(int oldX, int oldY,int newX,int newY);

//public void cannotMove();
//public void validMove(int x, int y);

}
